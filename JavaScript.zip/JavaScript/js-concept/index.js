let count = 0;

let a = () => {
  let textArea = document.getElementById("textarea").value;
  let description = document.getElementById("description");
  description.innerHTML = `${textArea}`;

  let words = textArea.split(" ");
  let letters = words.join("");

  for (let char of letters.split("")) {
    if (char.includes("a", "e", "i", "o", "u", "A", "E", "I", "O", "U")) {
      count++;
    }
  }

  let palindrom = false;
  for (let index = 0; index < textArea.length; index++) {
    if (index <= Math.ceil(textArea.length / 2)) {
      textArea[index] === textArea[textArea.length - index - 1]
        ? (palindrom = true)
        : (palindrom = false);
      continue;
    }
  }

  let analysis = document.getElementById("analysis");
  if (textArea === "") {
    analysis.innerHTML = `<pre>
    Words : 0 
    letters : 0 
    Vowels : ${(count = 0)} 
    Palindrom :
    </pre>`;
  } else {
    analysis.innerHTML = `<pre>
    Words : ${words.length} 
    letters without space : ${letters.length} 
    Vowels : ${count} 
    Palindrom : ${palindrom}
    </pre>`;
  }
};
