let icon=document.getElementById("span");

const thermometer=()=>{

    setTimeout(()=>{
        icon.innerHTML=`<i class="fas fa-thermometer-empty icon"></i>`;
        icon.style.color="yellow";
    },0000);

    setTimeout(()=>{
        icon.innerHTML=`<i class="fas fa-thermometer-quarter icon"></i>`;
        icon.style.color="yellow";
    },1000);

    setTimeout(()=>{
        icon.innerHTML=`<i class="fas fa-thermometer-half"></i>`;
        icon.style.color="yellow";
    },2000);

    setTimeout(()=>{
        icon.innerHTML=`<i class="fas fa-thermometer-three-quarters icon"></i>`;
        icon.style.color="yellow";
    },3000);

    setTimeout(()=>{
        icon.innerHTML=`<i class="fas fa-thermometer-full icon"></i>`;
        icon.style.color="red";
    },4000);

}

thermometer();

setInterval(thermometer, 5000);