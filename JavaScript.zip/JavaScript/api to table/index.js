let data;
let harsh = async () => {
  try {
    let setData = {
      header: {
        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
      },
    };

    let res = await fetch("https://fakestoreapi.com/products", setData);
    data = await res.json();

    console.log(data);
  } catch (err) {
    console.log(err.message);
  }

  display();
};

harsh();

function display() {
  let tr;
  tr = "";
  data.map((ele, index) => {
    tr += `
        <tr class="trData">
            <td>${ele.id}</td>
            <td>
            <img src="${ele.image}" alt="img" width="50px" height="50px">
            </td>
            <td class="title">${ele.title}</td>
            <td>${ele.price}</td>
            <td>${ele.category}</td>
            <td>${ele.description}</td>
            <td>count:${ele.rating.count} \n rate:${ele.rating.rate}</td>
            <td><button class="btn btn-danger" id=${index} onclick="deleteRow(this.id)">Delete</button> 
            <button data-toggle="modal" data-target="#exampleModal" class="btn btn-success mt-1" id=${index} onclick="view(this.id)">View</button></td>
        </tr>
        `;
  });

  let tableBody = document.getElementById("tableBody");
  tableBody.innerHTML = tr;
}

function deleteRow(index) {
  data.splice(index, 1);
  display();
}

let a, b, c, d, e, f, g, h;
function view(index) {
  a = data[index].id;
  b = data[index].image;
  c = data[index].title;
  d = data[index].price;
  e = data[index].category;
  f = data[index].description;
  g = data[index].rating.count;
  h = data[index].rating.rate;

  let modalForUpdate = `
    <div class="modal" class="modal fade" id="exampleModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="modal-title">${c}</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body" id="modal-body">

              <p>
                  Id : <input type="text" name="" id="" value="${a}" onchange="a=this.value">
              </p>
              <p>
              <img src="${b}" alt="img" width="150px" height="150px">
              </p>
              <p>
                  Image : <input type="text" name="" id="" value="${b}" onchange="b=this.value">
              </p>
              <p>
                  Title : <input type="text" name="" id="" value="${c}" onchange="c=this.value">
              </p>
              <p>
                  Price : <input type="text" name="" id="" value="${d}" onchange="d=this.value">
              </p>
              <p>
                  Category : <input type="text" name="" id="" value="${e}" onchange="e=this.value">
              </p>
              <p>
                  Description : <input type="text" name="" id="" value="${f}" onchange="f=this.value">
              </p>
              <p>
                  Count : <input type="text" name="" id="" value="${g}" onchange="g=this.value">
              </p>
              <p>
                  Rate : <input type="text" name="" id="" value="${h}" onchange="h=this.value">
              </p>

            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" data-dismiss="modal" id=${index} onclick="change(this.id,a,b,c,d,e,f,g,h)">Save changes</button>
            </div>

        </div>
    </div>
</div>`;

  let exampleModal = document.getElementById("exampleModal");
  let modal = document.createElement("div");
  modal.innerHTML = modalForUpdate;
  exampleModal.replaceWith(modal);
}

// function change(index,a1 = a,b1 = b,c1 = c,d1 = d,e1 = e,f1 = f,g1 = g,h1 = h) {
function change(index, a, b, c, d, e, f, g, h) {
  let newData = {
    id: a,
    image: b,
    title: c,
    price: d,
    category: e,
    description: f,
    rating: { count: g, rate: h },
  };
  data.splice(index, 1, newData);
  display();
}

function addData() {
  let inputId = document.getElementById("inputId").value;
  console.log(inputId);
  let inputImg = document.getElementById("inputImg").value;
  let inputTit = document.getElementById("inputTit").value;
  let inputPri = document.getElementById("inputPri").value;
  let inputCat = document.getElementById("inputCat").value;
  let inputDec = document.getElementById("inputDec").value;
  let inputCou = document.getElementById("inputCou").value;
  let inputRate = document.getElementById("inputRate").value;

  let newAddData = {
    id: inputId,
    image: inputImg,
    title: inputTit,
    price: inputPri,
    category: inputCat,
    description: inputDec,
    rating: { count: inputCou, rate: inputRate },
  };
  data.push(newAddData);
  display();
}
